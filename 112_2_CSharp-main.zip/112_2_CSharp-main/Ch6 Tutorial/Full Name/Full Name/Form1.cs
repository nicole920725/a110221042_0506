﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Full_Name
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The FullName method accepts arguments for a first
        // name, a middle name, and a last name. It returns
        // the full name.
      

        private void showFullNameButton_Click(object sender, EventArgs e)
        {
            // Variables to hold the first, middle, last, and full names
           
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
